"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var mongoose = require("mongoose");
var gameSchema = new mongoose.Schema({
    title: {
        type: String,
        required: true
    },
    genre: {
        type: String,
        required: true
    },
    platform: {
        type: String,
        required: true
    },
    review: {
        type: String,
        required: true
    },
    photo: {
        type: String,
        required: true
    }
});
exports.default = mongoose.model('Game', gameSchema);
