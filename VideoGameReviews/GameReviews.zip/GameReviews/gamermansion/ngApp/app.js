var gamermansion;
(function (gamermansion) {
    angular.module('gamermansion', ['ui.router', 'ngResource', 'ui.bootstrap', 'ngMaterial', 'ngMessages', 'angular-filepicker']).config(function ($stateProvider, $urlRouterProvider, $locationProvider, filepickerProvider) {
        filepickerProvider.setKey('AJXVPOIbTMavezvHYnC5Rz');
        $stateProvider
            .state('login', {
            url: '/',
            templateUrl: '/ngApp/views/login.html',
            controller: gamermansion.Controllers.LoginController,
            controllerAs: 'controller'
        })
            .state('register', {
            url: '/register',
            templateUrl: '/ngApp/views/register.html',
            controller: gamermansion.Controllers.RegisterController,
            controllerAs: 'controller'
        })
            .state('home', {
            url: '/home',
            templateUrl: '/ngApp/views/home.html',
            controller: gamermansion.Controllers.HomeController,
            controllerAs: 'controller'
        })
            .state('add', {
            url: '/add',
            templateUrl: '/ngApp/views/addGames.html',
            controller: gamermansion.Controllers.AddGamesController,
            controllerAs: 'controller'
        })
            .state('edit', {
            url: '/edit/:id',
            templateUrl: '/ngApp/views/editGames.html',
            controller: gamermansion.Controllers.EditGamesController,
            controllerAs: 'controller'
        })
            .state('about', {
            url: '/about',
            templateUrl: '/ngApp/views/about.html',
            controller: gamermansion.Controllers.AboutController,
            controllerAs: 'controller'
        })
            .state('notFound', {
            url: '/notFound',
            templateUrl: '/ngApp/views/notFound.html'
        });
        $urlRouterProvider.otherwise('/notFound');
        $locationProvider.html5Mode(true);
    });
})(gamermansion || (gamermansion = {}));
