var gamermansion;
(function (gamermansion) {
    var Controllers;
    (function (Controllers) {
        var HomeController = (function () {
            function HomeController(gameService, filepickerService, $scope, $state, platformService) {
                this.gameService = gameService;
                this.filepickerService = filepickerService;
                this.$scope = $scope;
                this.$state = $state;
                this.platformService = platformService;
                this.games = this.gameService.getAllGames();
                this.platforms = this.platformService.getAllPlatforms();
                var token = window.localStorage['token'];
                console.log(this.platforms);
                if (token) {
                    this.payload = JSON.parse(window.atob(token.split('.')[1]));
                    console.log(this.payload);
                }
            }
            HomeController.prototype.deleteGame = function (id) {
                if (this.payload.role === 'admin') {
                    this.gameService.removeGame(id);
                    alert('Success!');
                    this.$state.reload();
                }
                else {
                    alert('Denied. admins only.');
                }
                ;
            };
            HomeController.prototype.pickFile = function () {
                this.filepickerService.pick({ mimetype: 'image/*' }, this.fileUploaded.bind(this));
            };
            HomeController.prototype.fileUploaded = function (game) {
                this.game = game;
                this.$scope.$apply();
            };
            HomeController.prototype.findGames = function () {
                var _this = this;
                this.searching = true;
                this.gameService.findPlatformGames(JSON.parse(this.selectedPlatform).name).then(function (result) {
                    console.log(result);
                    _this.games = result;
                    _this.searching = false;
                });
            };
            return HomeController;
        }());
        Controllers.HomeController = HomeController;
        var AddGamesController = (function () {
            function AddGamesController(gameService, filepickerService, $scope, $state) {
                this.gameService = gameService;
                this.filepickerService = filepickerService;
                this.$scope = $scope;
                this.$state = $state;
                var token = window.localStorage['token'];
                if (token) {
                    this.payload = JSON.parse(window.atob(token.split('.')[1]));
                    console.log(this.payload);
                }
            }
            AddGamesController.prototype.addGame = function (photo) {
                if (this.payload.role === 'admin') {
                    this.game.photo = photo.url;
                    this.gameService.saveGame(this.game);
                    alert('Success!');
                    this.$state.go('home');
                }
                else {
                    alert('Denied. admins only.');
                }
            };
            AddGamesController.prototype.pickFile = function () {
                this.filepickerService.pick({ mimetype: 'image/*' }, this.addGame.bind(this));
            };
            AddGamesController.prototype.fileUploaded = function (game) {
                this.game = game;
                this.$scope.$apply();
            };
            return AddGamesController;
        }());
        Controllers.AddGamesController = AddGamesController;
        var EditGamesController = (function () {
            function EditGamesController($stateParams, gameService, filepickerService, $scope, $state) {
                this.$stateParams = $stateParams;
                this.gameService = gameService;
                this.filepickerService = filepickerService;
                this.$scope = $scope;
                this.$state = $state;
                this.id = $stateParams['id'];
                var token = window.localStorage['token'];
                if (token) {
                    this.payload = JSON.parse(window.atob(token.split('.')[1]));
                    console.log(this.payload);
                }
            }
            EditGamesController.prototype.editGame = function () {
                if (this.payload.role === 'admin') {
                    this.game._id = this.id;
                    this.gameService.saveGame(this.game);
                    alert('Success');
                }
                else {
                    alert('Denied. admins only.');
                }
                ;
                this.$state.go('home');
            };
            EditGamesController.prototype.pickFile = function () {
                this.filepickerService.pick({ mimetype: 'image/*' }, this.fileUploaded.bind(this));
            };
            EditGamesController.prototype.fileUploaded = function (photo) {
                this.game.url = photo.url;
                this.$scope.$apply();
                this.editGame();
            };
            return EditGamesController;
        }());
        Controllers.EditGamesController = EditGamesController;
        var LoginController = (function () {
            function LoginController(userService, $window, $state) {
                this.userService = userService;
                this.$window = $window;
                this.$state = $state;
            }
            LoginController.prototype.login = function () {
                if (this.isAdmin === true) {
                    this.userInfo.role = 'admin';
                    this.createSession();
                }
                else {
                    this.userInfo.role = 'guest';
                    this.createSession();
                }
            };
            LoginController.prototype.createSession = function () {
                var _this = this;
                this.userService.loginUser(this.userInfo).then(function (data) {
                    _this.$window.localStorage.setItem("token", JSON.stringify(data.token));
                    alert('login successful');
                    _this.$state.go('home');
                });
            };
            return LoginController;
        }());
        Controllers.LoginController = LoginController;
        var RegisterController = (function () {
            function RegisterController(userService, $state) {
                this.userService = userService;
                this.$state = $state;
            }
            RegisterController.prototype.signup = function () {
                var _this = this;
                this.userService.registerUser(this.user).then(function () {
                    alert('signup successful, please login');
                    _this.$state.go('login');
                });
            };
            return RegisterController;
        }());
        Controllers.RegisterController = RegisterController;
        var AboutController = (function () {
            function AboutController() {
            }
            return AboutController;
        }());
        Controllers.AboutController = AboutController;
    })(Controllers = gamermansion.Controllers || (gamermansion.Controllers = {}));
})(gamermansion || (gamermansion = {}));
