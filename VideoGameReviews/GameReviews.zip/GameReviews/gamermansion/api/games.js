"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var express = require("express");
var mongodb = require("mongodb");
var platform_1 = require("../models/platform");
var game_1 = require("../models/game");
var router = express.Router();
router.post('/', function (req, res) {
    if (req.body._id) {
        game_1.default.findByIdAndUpdate(req.body._id, { "$set": { "title": req.body.title, "genre": req.body.genre, "platform": req.body.platform, "review": req.body.review, "photo": req.body.url } }, { "new": true, "upsert": true }, function (err, updatedPlatform) {
            if (err) {
                res.send(err);
            }
            else {
                res.send(updatedPlatform);
            }
        });
    }
    else {
        var game = new game_1.default();
        game.title = req.body.title;
        game.genre = req.body.genre;
        game.platform = req.body.platform;
        game.review = req.body.review;
        game.photo = req.body.photo;
        game.save(function (err, newGame) {
            platform_1.default.findOne({ name: req.body.platform }).exec(function (err, result) {
                if (err) {
                    res.send(err);
                }
                else if (result === null) {
                    var platform = new platform_1.default();
                    platform.name = req.body.platform;
                    platform.save(function (err, newPlatform) {
                        platform_1.default.findByIdAndUpdate(newPlatform._id, { "$push": { "games": newGame._id } }, { "new": true, "upsert": true }, function (err, updatedPlatform) {
                            if (err) {
                                res.send(err);
                            }
                            else {
                                res.end();
                            }
                        });
                    });
                }
                else {
                    platform_1.default.findByIdAndUpdate(result._id, { "$push": { "games": newGame._id } }, { "new": true, "upsert": true }, function (err, updatedPlatform) {
                        if (err) {
                            res.send(err);
                        }
                        else {
                            res.end();
                        }
                    });
                }
            });
        });
    }
});
router.get('/', function (req, res) {
    game_1.default.find().populate('games').then(function (games) {
        res.json(games);
    });
});
router.get('/:platform', function (req, res) {
    game_1.default.find({ platform: req.params["platform"] }, function (error, result) {
        if (error) {
            res.send(error);
        }
        else {
            console.log(result);
            res.json(result);
        }
    });
});
router.delete('/:id', function (req, res) {
    var gameId = new mongodb.ObjectID(req.params['id']);
    game_1.default.remove({ _id: gameId }).then(function () {
        res.end();
    });
    game_1.default.update({ _id: gameId }, { $pull: { _id: gameId } }).then(function () {
        res.end();
    });
});
exports.default = router;
