import * as express from 'express';
import * as mongodb from 'mongodb';
import database from '../db';
import Platform from '../models/platform';
let router = express.Router();

router.get('/', (req, res) => {
  Platform.find({}, function(err, result) {
    console.log(result);
    res.json(result)
  })
})

export default router
